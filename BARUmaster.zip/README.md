# Recipes

Website Resep Makanan. 
Menampilkan berbagai resep makanan yang di ampil dari API https://github.com/tomorisakura/unofficial-masakapahariini-api
dibuat dengan Vanillaa Javascript, Boostrap 5, dan <3

![20220215_122057](https://user-images.githubusercontent.com/56707054/154023997-e9e33445-5555-4903-8afe-7e47f4b123db.png)
